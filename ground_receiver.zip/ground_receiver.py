import json
import boto3
import os
from datetime import datetime

s3 = boto3.client('s3')
kinesis = boto3.client('kinesis')

def lambda_handler(event, context):
    storage_bucket = os.environ['STORAGE_BUCKET']
    stream_name = os.environ['KINESIS_STREAM']
    
    for record in event['Records']:
        source_bucket = record['s3']['bucket']['name']
        source_key = record['s3']['object']['key']
        
        parts = source_key.split('/')
        if len(parts) >= 3:
            task_id = parts[1]
            filename = parts[-1]
        else:
            continue
        
        print(f"📡 Ground station received: {filename} for {task_id}")
        
        copy_source = {'Bucket': source_bucket, 'Key': source_key}
        dest_key = f"missions/{task_id}/{filename}"
        
        s3.copy_object(
            CopySource=copy_source,
            Bucket=storage_bucket,
            Key=dest_key
        )
        
        event_data = {
            "event_type": "data_received",
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "task_id": task_id,
            "filename": filename,
            "storage_location": f"s3://{storage_bucket}/{dest_key}",
            "size_bytes": record['s3']['object']['size']
        }
        
        kinesis.put_record(
            StreamName=stream_name,
            Data=json.dumps(event_data),
            PartitionKey=task_id
        )
        
        print(f"✅ Stored and event emitted: {filename}")
    
    return {'statusCode': 200}
