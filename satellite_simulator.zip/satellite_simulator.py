import json
import boto3
import os
from datetime import datetime
import random

s3 = boto3.client('s3')

def lambda_handler(event, context):
    downlink_bucket = os.environ['DOWNLINK_BUCKET']
    
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        obj = s3.get_object(Bucket=bucket, Key=key)
        command = json.loads(obj['Body'].read().decode('utf-8'))
        
        task_id = command['task_id']
        print(f"🛰️  Satellite received: {task_id}")
        
        satellite_data = {
            "task_id": task_id,
            "satellite_id": "SAT-SIM-001",
            "capture_time": datetime.utcnow().isoformat() + "Z",
            "telemetry": {
                "battery_voltage": round(random.uniform(27.5, 28.5), 2),
                "temperature_c": round(random.uniform(-10, 30), 1),
                "altitude_km": round(random.uniform(450, 550), 1),
                "status": "healthy"
            },
            "logs": [
                f"Command received: {command['command']}",
                f"Target: {command['target_location']['name']}",
                "Camera activated",
                "Image captured",
                "Data compressed",
                "Downlink ready"
            ],
            "imagery": {
                "image_id": f"IMG-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                "resolution_m": 0.5,
                "size_mb": round(random.uniform(50, 150), 1),
                "format": "GeoTIFF",
                "bands": command['parameters']['bands']
            }
        }
        
        downlink_key = f"data/{task_id}/satellite_data.json"
        s3.put_object(
            Bucket=downlink_bucket,
            Key=downlink_key,
            Body=json.dumps(satellite_data, indent=2),
            ContentType='application/json'
        )
        
        dummy_image = b'\x89PNG\r\n\x1a\n' + b'\x00' * 1024
        s3.put_object(
            Bucket=downlink_bucket,
            Key=f"data/{task_id}/image.png",
            Body=dummy_image,
            ContentType='image/png'
        )
        
        print(f"✅ Downlink complete: {task_id}")
    
    return {'statusCode': 200}
