import json
import boto3
import os
from datetime import datetime

s3 = boto3.client('s3')

def lambda_handler(event, context):
    uplink_bucket = os.environ['UPLINK_BUCKET']
    
    task_id = f"TASK-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}"
    
    command = {
        "task_id": task_id,
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "command": "CAPTURE_IMAGE",
        "target_location": {
            "latitude": 37.7749,
            "longitude": -122.4194,
            "name": "San Francisco"
        },
        "parameters": {
            "resolution": "high",
            "bands": ["visible", "infrared"]
        }
    }
    
    key = f"commands/{task_id}.json"
    s3.put_object(
        Bucket=uplink_bucket,
        Key=key,
        Body=json.dumps(command, indent=2),
        ContentType='application/json'
    )
    
    print(f"✅ Command uplinked: {task_id}")
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            'task_id': task_id,
            'status': 'uplinked',
            'location': f's3://{uplink_bucket}/{key}'
        })
    }
